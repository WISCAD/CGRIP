// CGRIP - Copyright 2011 University of Wisconsin-Madison.  All Rights Reserved.
// $HeadURL: http://homepages.cae.wisc.edu/~hamid/cgrip/example.cpp $
// $Id: example.cpp 152 2011-01-19 02:05:45Z shojaei $


/*! \file example.cpp
    \brief Example program for CGRIP.
    
    Details.
*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "CGRIP.h"

using namespace std;

int main(int argc, char **argv)
{
	if(argc<3){
		cout << "Usage : ./YOURBINARY.exe <circuit.aux> <solution.pl> [-o outputfile]"<<endl;
		exit(1);
	}
	
	char *outputfile;
	bool writeOutFlag = false;
	// read input files
	if(CGP_readBenchmark(argv[1])==0){
		cout<<"Error happened while reading the input files\n";
		exit(1);
	}
	
	// read coordinates from a file
	if(CGP_readPlacement(argv[2])==0){
		cout<<"Error happened while reading placement info\n";
		exit(1);
	}
	
	// set coordinate of a specific object
	/*if(CGP_setNodeCoordinate("o259469", 5932, 11691)==0){
		cout<<"Error happened while setting coordinates\n";
		exit(1);
	}*/
	
	// run CGRIP and route the nets(time out:900s)
	if(CGP_runRouting(300,900,1)==0){
		cout<<"Error happened while routing the nets\n";
		exit(1);
	}
	
	
	// write the output in ISPD 08 format
	for(int i = 3; i < argc; ++i){
	    if(argv[i] == string("-o")){
	      if(i+1 < argc){
	        outputfile = argv[++i];
	        writeOutFlag = true;
	      }
	      else{
	        cout << "option -o requires an argument" << endl;
	        cout << "Usage : ./CGRIP.exe <circuit.aux> <solution.pl> [-o outputfile]"<<endl;
	        return 0;
	      }
	    }
	}
	
	if(writeOutFlag){
		if(CGP_writeOutput(outputfile)==0){
			cout<<"Error happened while writing the routes\n";
			exit(1);
		}
	}
	cout<<endl;
	//print results
	cout << "Total WL:" << CGP_getWirelength()    << endl;
	cout << "Total OF:" << CGP_getTotalOverflow() << endl;
	cout << "Max OF:"   << CGP_getMaxOverflow()   << endl;
	
	int n;
	int *ofs;
	ofs = CGP_getLayerNCongestion(0, &n);
	if(ofs==NULL){
		cout<<"Error happened while getting results\n"<<endl;
		exit(1);
	}
	cout<<"some overflows:"<<endl;
	for(int i=0; i<10; ++i)
		cout<<i<<":"<<ofs[i]<<"\t";
	cout<<endl<<endl;
	
	
	//important to dispose
	CGP_disposeCGRIP();
	
	
  return 0;
}

